<?php
// Simulação de autenticação (substitua por lógica real)
$usuarios = array(
    "usuario1" => "senha1",
    "usuario2" => "senha2"
);

$username = $_POST['username'];
$password = $_POST['password'];

if (isset($usuarios[$username]) && $usuarios[$username] === $password) {
    // Autenticação bem-sucedida, redireciona para a página de denúncias
    header("Location: denuncia.html");
} else {
    // Falha na autenticação, redireciona de volta para o login
    header("Location: index.html");
}
?>
