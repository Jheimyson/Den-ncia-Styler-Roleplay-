<?php
// Processamento do cadastro aqui
$username = $_POST['username'];
$password = $_POST['password'];

// Aqui você pode salvar os dados do novo usuário no banco de dados ou fazer qualquer outro processamento necessário

// Redireciona de volta para a página de login após o cadastro
header("Location: index.html");
?>
